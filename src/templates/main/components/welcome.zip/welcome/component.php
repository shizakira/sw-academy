<?php
$arResult['title'] = $arParams['title'];
$arResult['desc'] = $arParams['desc'];
$arResult['desc_bold'] = $arParams['desc_bold'];
$arResult['button_text'] = $arParams['button_text'];
